// ===================================
// DATOS DE LOS RECURSOS EDUCATIVOS
// ===================================

const resourcesData = {
    1: {
        title: "Fundamentos de HTML y CSS",
        category: "Programación",
        level: "Principiante",
        author: "Juan Pérez",
        duration: "4 semanas",
        price: "Gratis",
        description: "Aprende los conceptos básicos para crear páginas web profesionales.",
        content: `
            <h4>Descripción Completa</h4>
            <p>Este curso cubre los fundamentos esenciales de HTML5 y CSS3 para desarrollar sitios web modernos. 
            Aprenderás a:</p>
            <ul style="margin-left: 1.5rem;">
                <li>Estructura semántica de documentos HTML</li>
                <li>Etiquetas HTML5 avanzadas</li>
                <li>Selectores CSS y especificidad</li>
                <li>Modelos de caja y posicionamiento</li>
                <li>Flexbox básico</li>
            </ul>
            <p><strong>Requisitos:</strong> Ninguno, totalmente para principiantes.</p>
            <p><strong>Certificado:</strong> Sí, incluido al finalizar.</p>
        `
    },
    2: {
        title: "Diseño Responsive con CSS",
        category: "Diseño Web",
        level: "Intermedio",
        author: "María García",
        duration: "6 semanas",
        price: "$99",
        description: "Crea sitios que se adapten a cualquier dispositivo móvil o desktop.",
        content: `
            <h4>Descripción Completa</h4>
            <p>Aprende a crear diseños que funcionan perfectamente en todos los dispositivos.</p>
            <ul style="margin-left: 1.5rem;">
                <li>Media queries y puntos de ruptura (breakpoints)</li>
                <li>Unidades relativas (em, rem, vw, vh)</li>
                <li>Grillas fluidas y flexibles</li>
                <li>Imágenes responsivas</li>
                <li>Mejores prácticas mobile-first</li>
            </ul>
            <p><strong>Requisitos:</strong> Conocimientos básicos de HTML y CSS.</p>
            <p><strong>Proyecto Final:</strong> Crear un portafolio responsive completo.</p>
        `
    },
    3: {
        title: "JavaScript Avanzado",
        category: "Programación",
        level: "Avanzado",
        author: "Carlos López",
        duration: "8 semanas",
        price: "$149",
        description: "Domina técnicas avanzadas de programación en JavaScript moderno.",
        content: `
            <h4>Descripción Completa</h4>
            <p>Profundiza en las características avanzadas de JavaScript ES6+ y más allá.</p>
            <ul style="margin-left: 1.5rem;">
                <li>Closures y scope en profundidad</li>
                <li>Promesas y async/await</li>
                <li>Destructuring y spread operator</li>
                <li>Programación orientada a objetos</li>
                <li>Manipulación del DOM avanzada</li>
                <li>Event listeners y delegación</li>
            </ul>
            <p><strong>Requisitos:</strong> JavaScript fundamentals.</p>
            <p><strong>Proyecto Final:</strong> Aplicación web interactiva completa.</p>
        `
    },
    4: {
        title: "SQL y Gestión de Bases de Datos",
        category: "Base de Datos",
        level: "Intermedio",
        author: "Ana Rodríguez",
        duration: "5 semanas",
        price: "$79",
        description: "Aprende a crear, manipular y optimizar bases de datos con SQL.",
        content: `
            <h4>Descripción Completa</h4>
            <p>Domina los fundamentos de SQL y administración de bases de datos relacionales.</p>
            <ul style="margin-left: 1.5rem;">
                <li>Creación y diseño de tablas</li>
                <li>Consultas SELECT, INSERT, UPDATE, DELETE</li>
                <li>JOINs y subconsultas</li>
                <li>Índices y optimización</li>
                <li>Transacciones y ACID</li>
                <li>Respaldos y recuperación</li>
            </ul>
            <p><strong>Requisitos:</strong> Lógica básica de programación.</p>
            <p><strong>Base de Datos:</strong> Usaremos PostgreSQL o MySQL.</p>
        `
    },
    5: {
        title: "Fundamentos de Redes Informáticas",
        category: "Redes",
        level: "Principiante",
        author: "Roberto Silva",
        duration: "4 semanas",
        price: "Gratis",
        description: "Entiende cómo funcionan las redes y la comunicación en internet.",
        content: `
            <h4>Descripción Completa</h4>
            <p>Aprende los conceptos fundamentales de redes informáticas.</p>
            <ul style="margin-left: 1.5rem;">
                <li>Modelos OSI y TCP/IP</li>
                <li>Direcciones IP y máscaras de subred</li>
                <li>Protocolos: TCP, UDP, HTTP, HTTPS</li>
                <li>DNS y DHCP</li>
                <li>Firewalls y seguridad básica</li>
                <li>Wi-Fi y conectividad inalámbrica</li>
            </ul>
            <p><strong>Requisitos:</strong> Ninguno, para principiantes.</p>
            <p><strong>Laboratorio:</strong> Simulaciones prácticas con Cisco Packet Tracer.</p>
        `
    },
    6: {
        title: "UX/UI Design: Diseñando Experiencias",
        category: "Diseño Web",
        level: "Avanzado",
        author: "Laura Martínez",
        duration: "10 semanas",
        price: "$199",
        description: "Crea interfaces hermosas y funcionales que los usuarios amarán.",
        content: `
            <h4>Descripción Completa</h4>
            <p>Desarrolla habilidades profesionales en diseño de experiencia de usuario.</p>
            <ul style="margin-left: 1.5rem;">
                <li>Principios de UX/UI</li>
                <li>Research y análisis de usuarios</li>
                <li>Wireframing y prototipado</li>
                <li>Teoría del color y tipografía</li>
                <li>Accesibilidad web (WCAG)</li>
                <li>Herramientas: Figma, Adobe XD</li>
                <li>Usability testing</li>
            </ul>
            <p><strong>Requisitos:</strong> Conocimiento en diseño visual.</p>
            <p><strong>Proyecto Final:</strong> Rediseño completo de un sitio web.</p>
        `
    }
};

// ===================================
// FUNCIONES DE FILTRADO
// ===================================

document.addEventListener('DOMContentLoaded', function() {
    initializeFilters();
    initializeModalEvents();
});

function initializeFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Actualizar botón activo
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Filtrar tarjetas
            const filterValue = this.dataset.filter;
            filterCards(filterValue);
        });
    });
}

function filterCards(filterValue) {
    const cards = document.querySelectorAll('.resource-card');
    
    cards.forEach(card => {
        const cardCategory = card.dataset.category;
        
        if (filterValue === 'todos' || cardCategory === filterValue) {
            // Mostrar tarjeta con animación
            card.style.display = 'block';
            card.style.animation = 'none';
            setTimeout(() => {
                card.style.animation = 'fadeInUp 0.5s ease';
            }, 10);
        } else {
            // Ocultar tarjeta
            card.style.display = 'none';
        }
    });
}

// ===================================
// FUNCIONES DEL MODAL
// ===================================

function initializeModalEvents() {
    const modal = document.getElementById('detailsModal');
    const closeBtn = document.querySelector('.close');
    const detailButtons = document.querySelectorAll('.btn-details');
    
    // Abrir modal
    detailButtons.forEach(button => {
        button.addEventListener('click', function() {
            const resourceId = this.dataset.id;
            openModal(resourceId);
        });
    });
    
    // Cerrar modal
    closeBtn.addEventListener('click', closeModal);
    
    // Cerrar modal al hacer clic fuera
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            closeModal();
        }
    });
}

function openModal(resourceId) {
    const modal = document.getElementById('detailsModal');
    const modalBody = document.getElementById('modalBody');
    const resource = resourcesData[resourceId];
    
    if (resource) {
        let htmlContent = `
            <h3>${resource.title}</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.5rem;">
                <div>
                    <p><strong>📚 Categoría:</strong> ${resource.category}</p>
                    <p><strong>📊 Nivel:</strong> ${resource.level}</p>
                </div>
                <div>
                    <p><strong>⏱️ Duración:</strong> ${resource.duration}</p>
                    <p><strong>💰 Precio:</strong> ${resource.price}</p>
                </div>
            </div>
            <p><strong>👤 Autor:</strong> ${resource.author}</p>
            ${resource.content}
            <div style="margin-top: 1.5rem;">
                <button onclick="enrollResource('${resource.title}')" style="
                    width: 100%;
                    padding: 0.75rem;
                    background-color: #667eea;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    font-size: 1rem;
                    font-weight: bold;
                    cursor: pointer;
                ">Inscribirse Ahora</button>
            </div>
        `;
        
        modalBody.innerHTML = htmlContent;
        modal.style.display = 'block';
    }
}

function closeModal() {
    const modal = document.getElementById('detailsModal');
    modal.style.display = 'none';
}

function enrollResource(resourceTitle) {
    alert(`¡Gracias por tu interés! Te has inscrito a: ${resourceTitle}\n\nProximamente recibirás un correo de confirmación.`);
    closeModal();
    
    // Cambiar color dinámicamente como bonus
    document.body.style.backgroundColor = '#e8f5e9';
    setTimeout(() => {
        document.body.style.backgroundColor = '#f8f9fa';
    }, 2000);
}

// ===================================
// SCROLL SUAVE EN NAVEGACIÓN
// ===================================

document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        
        if (href.startsWith('#')) {
            e.preventDefault();
            const target = document.querySelector(href);
            
            if (target) {
                // Actualizar enlaces activos
                document.querySelectorAll('.nav-link').forEach(l => {
                    l.classList.remove('active');
                });
                this.classList.add('active');
                
                // Scroll suave
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }
    });
});

// ===================================
// ACTUALIZAR NAV ACTIVO AL HACER SCROLL
// ===================================

window.addEventListener('scroll', function() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');
    
    let currentSection = '';
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        
        if (window.scrollY >= sectionTop - 200) {
            currentSection = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === '#' + currentSection) {
            link.classList.add('active');
        }
    });
});

// ===================================
// ANIMACIÓN DE CONTADORES (BONUS)
// ===================================

function animateCounters() {
    const counters = document.querySelectorAll('.counter');
    
    counters.forEach(counter => {
        const target = +counter.getAttribute('data-target');
        const increment = target / 100;
        let current = 0;
        
        const updateCount = () => {
            if (current < target) {
                current += increment;
                counter.innerText = Math.ceil(current);
                setTimeout(updateCount, 50);
            } else {
                counter.innerText = target;
            }
        };
        
        updateCount();
    });
}

// ===================================
// VALIDACIÓN DE FORMULARIO (SI EXISTE)
// ===================================

function validateForm(formId) {
    const form = document.getElementById(formId);
    
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            let isValid = true;
            const inputs = form.querySelectorAll('input[required], textarea[required]');
            
            inputs.forEach(input => {
                if (input.value.trim() === '') {
                    isValid = false;
                    input.style.borderColor = 'red';
                    input.style.backgroundColor = '#ffe6e6';
                } else {
                    input.style.borderColor = 'green';
                    input.style.backgroundColor = '#e6ffe6';
                }
            });
            
            if (isValid) {
                alert('¡Formulario válido! Gracias por tu mensaje.');
                form.reset();
                inputs.forEach(input => {
                    input.style.borderColor = '';
                    input.style.backgroundColor = '';
                });
            } else {
                alert('Por favor completa todos los campos requeridos.');
            }
        });
    }
}

// ===================================
// FUNCIÓN PARA CAMBIAR TEMA (BONUS)
// ===================================

function toggleDarkMode() {
    document.body.classList.toggle('dark-mode');
    localStorage.setItem('darkMode', document.body.classList.contains('dark-mode'));
}

// Cargar preferencia de tema guardada
if (localStorage.getItem('darkMode') === 'true') {
    document.body.classList.add('dark-mode');
}

// ===================================
// MOSTRAR NOTIFICACIÓN
// ===================================

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        background-color: ${type === 'success' ? '#4caf50' : type === 'error' ? '#f44336' : '#2196f3'};
        color: white;
        border-radius: 4px;
        z-index: 10000;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// ===================================
// EXPORTAR RECURSOS A JSON (BONUS)
// ===================================

function exportResourcesAsJSON() {
    const dataStr = JSON.stringify(resourcesData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'recursos_educativos.json';
    link.click();
    showNotification('Recursos exportados correctamente', 'success');
}

// Log en consola para debugging
console.log('%c¡Bienvenido a Galería de Recursos Educativos!', 'color: #667eea; font-size: 18px; font-weight: bold;');
console.log('Total de recursos disponibles:', Object.keys(resourcesData).length);